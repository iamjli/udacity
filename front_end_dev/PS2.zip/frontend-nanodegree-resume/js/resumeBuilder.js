
var bio = {
    'name': 'Johnny Li',
    'role': 'student',
    'contacts': {
        'mobile': '123-456-7890',
        'email': 'johnnyli@mit.edu',
        'github': 'iamjli',
        'location': 'Cambridge, MA',
        'twitter': 'iamjli'
    },
    'welcomeMessage': 'Welcome to my profile. Boiler plate shit.',
    'skills': [
        'beer',
        'halp',
        'teaching',
        'JS',
    ],
    'biopic': 'http://placecage.com/c/800/400'
};

var work = {
    'jobs': [{
        'employer': 'Art of Problem Solving',
        'title': 'Online Teaching Assisstant',
        'location': 'San Diego, CA',
        'dates': 'Jan 2012 - Present',
        'description': 'I coordinate with another assistant to help clarify complex math concepts to 60 gifted upper-school students.'
    }, {
        'employer': 'Orange County Math Circle',
        'title': 'Founder and Advisory Board Member',
        'location': 'Orange County, CA',
        'dates': 'Sep 2008 - Present',
        'description': 'OCMC is a student-run, nonprofit community service organization where high school students gather to explore advanced problem solving topics and teach underserved students in Orange County. As a founder, I wrote the business plan and managed operations of the organization for four years. Currently, I serve as an advisor for the organization.'
    }, {
        'employer': 'CancerIQ',
        'title': 'Summer Intern',
        'location': 'Chicago, IL',
        'dates': 'Jun 2015 - Aug 2015',
        'description': 'I recommended clinical trials based on questionnaire results'
    }, {
        'employer': 'National Association of Math Circles',
        'title': 'Advisory Board Member',
        'location': 'Berkeley, CA',
        'dates': 'Sep 2012 - May 2015',
        'description': 'I sat on the steering committee for the National Association of Math Circles for my experience with the Orange County Math Circle. I advocated for and encouraged the student-led initiatives that provide math and science services to the community.'
    }, {
        'employer': 'Harvard Stem Cell Institute',
        'title': 'Undergraduate Researcher',
        'location': 'Cambridge, MA',
        'dates': 'Jan 2012 - May 2015',
        'description': 'I am in the Melton Laboratory studying the regulatory mechanism and promoter region for the novel hormone, betatrophin. This project has promising applications for treatment of Type I and II diabetes.'
    }, {
        'employer': 'Center for Computational Science of Microstructure',
        'title': 'Researcher',
        'location': 'Irvine, CA',
        'dates': 'Sep 2009 - Feb 2014',
        'description': 'I have been working in Dr. John \'s laboratory to study the effects of certain cell characteristics on tumor cluster growth. Our work has culminated in a first author publication in the Journal of Theoretical Biology.'
    }, {
        'employer': 'Evotec',
        'title': 'Guest Scientist',
        'location': 'Goettingen, Germany',
        'dates': 'Jun 2013 - Aug 2013',
        'description': 'Using facilities at Evotec, I conducted screens to search for compounds which upregulate betatrophin expression. I was able to identify several protein kinases which might be involved in the betatrophin signaling cascade.'
    }]
};

var projects = {
    'projects': [{
        'title': 'Effects of cell compressibility, motility and contact inhibition on tumor growth',
        'dates': '9/1/08-2/1/14',
        'description': 'conducted at UC Irvine with John Lowengrub',
        'images': [
            'http://placecage.com/gif/200/200',
            'http://placecage.com/c/200/200'
        ]
    }]
};

var education = {
    'schools': [{
        'name': 'Harvard University',
        'location': 'Cambridge, MA',
        'degree': 'AB',
        'majors': [
            'Stem cell biology',
            'CS'
        ],
        'dates': '9/1/11-5/31/15',
        'url': 'test.com'
    }],
    'onlineCourses': [{
        'title': 'front-end dev',
        'school': 'Udacity',
        'date': '12/23/15-pres',
        'url': 'udacity.com'
    }]
};

var DATA = '%data%';


bio.display = function() {
    var header = $('#header');
    var flex = $('.flex-item');

    var formattedName = HTMLheaderName.replace(DATA, bio.name);
    header.append(formattedName);

    var formattedRole = HTMLheaderRole.replace(DATA, bio.role);
    header.append(formattedRole);

    header.append(HTMLcontactStart);
    $('#lets-connect').append(HTMLcontactStart);

    var formattedMobile = HTMLmobile.replace(DATA, bio.contacts.mobile);
    $('.flex-item').append(formattedMobile);

    var formattedEmail = HTMLemail.replace(DATA, bio.contacts.email);
    $('.flex-item').append(formattedEmail);

    var formattedGithub = HTMLgithub.replace(DATA, bio.contacts.github);
    $('.flex-item').append(formattedGithub);

    var formattedTwitter = HTMLtwitter.replace(DATA, bio.contacts.twitter);
    $('.flex-item').append(formattedTwitter);

    var formattedLocation = HTMLlocation.replace(DATA, bio.contacts.location);
    $('.flex-item').append(formattedLocation);

    var formattedPic = HTMLbioPic.replace(DATA, bio.biopic);
    header.append(formattedPic);

    var formattedWelcome = HTMLwelcomeMsg.replace(DATA, bio.welcomeMessage);
    header.append(formattedWelcome);

    if (bio.skills.length > 0) {
        header.append(HTMLskillsStart);

        bio.skills.forEach(function(skill) {
            $('#skills').append(HTMLskills.replace(DATA, skill));
        });
    }
};

work.display = function() {
    if (work.jobs.length > 0) {
        var HTMLworkformatted;
        work.jobs.forEach(function(job) {
            $('#workExperience').append(HTMLworkStart);

            HTMLworkformatted = HTMLworkEmployer.replace(DATA, job.employer) + HTMLworkTitle.replace(DATA, job.title);
            $('.work-entry:last').append(HTMLworkformatted);

            var formattedLocation = HTMLworkLocation.replace(DATA, job.location);
            var formattedDates = HTMLworkDates.replace(DATA, job.dates);
            var formattedDescription = HTMLworkDescription.replace(DATA, job.description);

            $('.work-entry:last').append(formattedLocation);
            $('.work-entry:last').append(formattedDates);
            $('.work-entry:last').append(formattedDescription);
        });
    }
};

projects.display = function() {
    for (var project in projects.projects) {
        if (project in projects.projects) {
            $('#projects').append(HTMLprojectStart);

            var formattedTitle = HTMLprojectTitle.replace(DATA, projects.projects[project].title);
            $('.project-entry:last').append(formattedTitle);

            var formattedDates = HTMLprojectDates.replace(DATA, projects.projects[project].dates);
            $('.project-entry:last').append(formattedDates);

            var formattedDescription = HTMLprojectDescription.replace(DATA, projects.projects[project].description);
            $('.project-entry:last').append(formattedDescription);

            if (projects.projects[project].images.length > 0) {
                for (var image in projects.projects[project].images) {
                    if (image in projects.projects[project].images) {
                        var formattedImage = HTMLprojectImage.replace(DATA, projects.projects[project].images[image]);
                        $('.project-entry:last').append(formattedImage);
                    }
                }
            }
        }
    }
};

education.display = function() {
    education.schools.forEach(function(school) {
        $('#education').append(HTMLschoolStart);

        var formattedName = HTMLschoolName.replace(DATA, school.name);
        var formattedDegree = HTMLschoolDegree.replace(DATA, school.degree);
        $('.education-entry:last').append(formattedName + formattedDegree);

        var formattedDates = HTMLschoolDates.replace(DATA, school.dates);
        $('.education-entry:last').append(formattedDates);

        var formattedLocation = HTMLschoolLocation.replace(DATA, school.location);
        $('.education-entry:last').append(formattedLocation);

        school.majors.forEach(function(val) {
            var formattedMajor = HTMLschoolMajor.replace(DATA, val);
            $('.education-entry:last').append(formattedMajor);
        });
    });

    education.onlineCourses.forEach(function(course) {
        $('#education').append(HTMLonlineClasses);
        $('#education').append(HTMLschoolStart);

        var formattedTitle = HTMLonlineTitle.replace(DATA, course.title);
        var formattedSchool = HTMLonlineSchool.replace(DATA, course.school);
        $('.education-entry:last').append(formattedTitle + formattedSchool);

        var formattedCourseDates = HTMLonlineDates.replace(DATA, course.date);
        $('.education-entry:last').append(formattedCourseDates);

        var formattedURL = HTMLonlineURL.replace(DATA, course.url);
        $('.education-entry:last').append(formattedURL);
    });
};

bio.display();
work.display();
projects.display();
education.display();

$('#mapDiv').append(googleMap);